nobs.systemfit <- function( object, ... ) {
   return( object$df.residual + object$rank )
}
